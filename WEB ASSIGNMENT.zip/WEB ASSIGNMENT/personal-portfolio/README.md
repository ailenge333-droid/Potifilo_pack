# Personal Portfolio Website

## Project Overview
This project is a personal portfolio website designed to showcase an individual's academic achievements, personal interests, and professional skills. It includes a login page, home page, profile page, yearly results pages, and additional content pages.

## Features
- **Login Page**: A secure login form with basic validation for username and password.
- **Home Page**: Displays the user's name, profile picture, biography, and a navigation menu.
- **Profile Page**: Summarizes the user's academic profile, including a table of results.
- **Yearly Results Pages**: Dedicated pages for displaying academic results for each year.
- **Extra Pages**: Additional content related to hobbies, career goals, or personal projects.
- **Image Slideshow**: A dynamic slideshow showcasing images relevant to the portfolio.
- **Dropdown Menu**: An interactive dropdown for navigating academic results.
- **Embedded Video**: A video explaining how to navigate the website.

## File Structure
```
personal-portfolio
├── assets
│   ├── css
│   │   └── style.css
│   ├── js
│   │   ├── main.js
│   │   ├── validation.js
│   │   ├── slideshow.js
│   │   └── dropdown.js
│   ├── images
│   │   └── (image files)
│   └── videos
│       └── (video files)
├── pages
│   ├── index.html
│   ├── home.html
│   ├── profile.html
│   ├── page1.html
│   ├── page2.html
│   └── results
│       ├── year1.html
│       ├── year2.html
│       ├── year3.html
│       └── year4.html
└── README.md
```

## Setup Instructions
1. Clone the repository to your local machine.
2. Open the `index.html` file in a web browser to access the login page.
3. Use the navigation menu to explore different sections of the portfolio.

## Technologies Used
- HTML5
- CSS3
- JavaScript
- Responsive Design

## Future Enhancements
- Implement backend functionality for user authentication.
- Add more interactive features and animations.
- Expand the content in extra pages to include more personal projects and achievements.

## License
This project is open-source and available for anyone to use and modify.